import SectionWrapper from "./SectionWrapper";

// Export Section Wrapper
export { SectionWrapper };
